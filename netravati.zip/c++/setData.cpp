#include<iostream>
using namespace std;
class Student{
	private:
		int rollNo;
		string name;
	public:
		void setData(int r, string n){
			rollNo=r,
			name=n;
			
		}
		void display(){
			cout <<"Roll No :" << rollNo <<",Name:"<<name<<endl;
		}
};
int main(){
	Student s1,s2;
	s1.setData(1,"Asha");
	s2.setData(2,"Netra");
	s1.display();
	s2.display();
	return 0;
}
