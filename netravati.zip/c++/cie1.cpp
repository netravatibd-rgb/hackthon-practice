#include <iostream>
using namespace std;

int calculateTotal(int m1, int m2)
{
    return m1 + m2;
}

int calculateTotal(int m1, int m2, int m3)
{
    return m1 + m2 + m3;
}

int main()
{
    int m1, m2, m3;

    cout << "Enter marks of 3 subjects: ";
    cin >> m1 >> m2 >> m3;

    cout << "Total marks = " << calculateTotal(m1, m2, m3) << endl;

    cout << "Enter marks of 2 subjects: ";
    cin >> m1 >> m2;

    cout << "Total marks = " << calculateTotal(m1, m2) << endl;

    return 0;
}
