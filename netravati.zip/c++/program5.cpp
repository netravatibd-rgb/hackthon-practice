#include<iostream>
#include <cstring>
using namespace std;
class Student {
	private:
		string name;
		int age;
		int* marks;

public:
	Student() {
		name = "Unknown";
		age = 0;
		marks = new int(0);
		cout << "[Default Constructor] called for " << name << endl; 
	}
	Student(string n, int a, int m) {
		name = n;
		age = a;
		marks = new int(m);
		cout << "[Parametarized Constructor] called for" << name << endl;
	}
	Student(const Student& other) {
		name = other.name;
		age = other.age;
		marks = new int(*other.marks);
		cout << "[Copy Constructor] called for " << name << endl;
	}
	~Student() {
		cout << "[Destructor] called for " << name << endl;
		delete marks;
	}
	void display() {
		cout << "Name: " << name << ", Age: " << age <<", Marks: " << marks << endl;
	}
};
int main()  {
	cout << "---Creating s1 using Default Constructor ----\n";
	Student s1;
	s1.display();;
	
	cout << "\n-----Creating s2 using Parameterized Constructor ---\n";
	Student s2("Alice", 20, 85);
	s2.display();
	
	cout << "\n----Creating s3 as a Copy of s2 ---\n";
	Student s3(s2);
	s3.display();
	
	cout << "\n----End of main: Destructor will now be called in reverse order ----\n";
	return 0;
}
