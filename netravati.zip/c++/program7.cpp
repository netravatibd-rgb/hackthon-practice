#include <iostream>
using namespace std;
 class Student
 {
 	int rollNo;
 	string name;
 	int marks;
public:
	void getData()
	{
		cout << "Enter Roll No: ";
		cin >> rollNo;
		
		cout << "Enter Name: ";
		cin >> name;
		
		cout << "Enter Marks: ";
		cin >> marks;
	}
	void display()
	{
		cout << "Roll No: " << rollNo << endl;
		cout << "Name: " << name << endl;
		cout << "Marks: " << marks << endl;
		
	}
	void compare(Student s)
	{
		if(marks > s.marks)
			cout << name << " has higher marks." << endl;
		else if(marks < s.marks) 
			cout << marks << " has hiher marks." << endl;
		else
			cout << "Both have equal marks." << endl;
	}
 };
 int main()
 {
 	Student s[2];
 	cout << "Enter details of Student 1:\n";
 	s[0].getData();
 	cout << "\nEnter details of Student 2:\n";
 	s[1].getData();
 	cout << "\nStudent Details:\n";
 	
 	for (int i=0; i<2; i++)
 	{
 		s[i].display();
 		cout << endl;
	}
	s[0].compare(s[1]);
	return 0;
 }
