//Write a C++ program using control statement and loops to solve a computat
//1)Prime check 2)Pattern Printing
#include <iostream>
using namespace std;

// Function to check whether a number is prime
bool isPrime(int n) {
    if (n < 2)
        return false;

    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0)
            return false;
    }

    return true;
}

int main() {

    // ------ 1) Prime Check ------
    int n;

    cout << "=== Prime Check ===\n";
    cout << "Enter a number: ";
    cin >> n;

    if (isPrime(n))
        cout << n << " is a prime number.\n";
    else
        cout << n << " is not a prime number.\n";

    // Print all prime numbers up to n
    cout << "Primes up to " << n << ": ";

    for (int i = 2; i <= n; i++) {
        if (isPrime(i))
            cout << i << " ";
    }

    cout << endl;


    // ------ 2) Pattern Printing ------
    int rows;

    cout << "\n=== Pattern Printing ===\n";
    cout << "Enter number of rows: ";
    cin >> rows;


    // Right Triangle
    cout << "\nRight Triangle (Stars):\n";

    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            cout << "*";
        }
        cout << endl;
    }


    // Pyramid
    cout << "\nPyramid:\n";

    for (int i = 1; i <= rows; i++) {

        // Print spaces
        for (int j = 1; j <= rows - i; j++) {
            cout << " ";
        }

        // Print stars
        for (int j = 1; j <= 2 * i - 1; j++) {
            cout << "*";
        }

        cout << endl;
    }

    return 0;
}
