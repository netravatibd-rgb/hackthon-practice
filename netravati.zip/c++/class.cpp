#include<iostream>
using namespace std;
class Student {
	public:
		int rollNo;
		string name;
		void display(){
			cout <<"rollNo:"<<rollNo <<endl;
			cout <<"Name:" << name <<endl;
		}
};
int main(){
	Student s1;
	s1.rollNo=101;
	s1.name="Ravi";
	s1.display();
	return 0;
}
