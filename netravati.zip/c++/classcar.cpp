#include<iostream>
using namespace std;
class Car{
	public:
		string brand;
		int speed;
		void drive(){
			cout<<brand<<" is driving at "<<speed<<"km/h"<<endl;
		}
};
int main(){
	Car car1 ;
	car1.brand="Toyota";
	car1.speed=80;
	Car car2;
	car2.brand="Hounda";
	car2.speed=100;
	car1.drive();
	car2.drive();
	return 0;
}
