#include<iostream>
using namespace std;
class Calculator{
	private:
		int num1, num2;
	public:
		Calculator(int a, int b){
			num1 =a;
			num2 =b;
		}
		int add(){
			return num1 + num2;
		}
		int substract(){
			return num1-num2;
		}
};
int main(){
	Calculator calc(15,5);
	cout<<"sum="<<calc.add()<<endl;
	cout<<"Diference="<<calc.substract()<<endl;
	return 0;
}
