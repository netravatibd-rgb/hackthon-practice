#include <iostream>
using namespace std;
int getFibonacci(int n) {
    if (n <= 1) {
        return n;
    }
    return getFibonacci(n - 1) + getFibonacci(n - 2);
int main() {
    int fibonacciTerms;
    cout << "=== Fibonacci Series Demonstration ===" << endl;
    cout << "Enter the number of terms for the Fibonacci series: ";
    cin >> fibonacciTerms;

    if (fibonacciTerms <= 0) {
        cout << "Enter a positive number" << endl;
    } else {
        cout << "Fibonacci Series up to " << fibonacciTerms << " terms: " << endl;
        for (int i = 0; i < fibonacciTerms; i++) {
            cout << getFibonacci(i) << " ";
        }
        cout << endl;
    }

    return 0;
}
