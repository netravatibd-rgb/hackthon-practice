#include <iostream>

using namespace std;

// Recursive function to calculate the factorial of a number
unsigned long long calculateFactorial(int n) {
    // Base case: factorial of 0 or 1 is 1
    if (n <= 1) {
        return 1;
    }
    // Recursive case: n! = n * (n-1)!
    return n * calculateFactorial(n - 1);
}

// Recursive function to find the nth Fibonacci number
int getFibonacci(int n) {
    // Base cases: F(0) = 0, F(1) = 1
    if (n <= 1) {
        return n;
    }
    // Recursive case: F(n) = F(n-1) + F(n-2)
    return getFibonacci(n - 1) + getFibonacci(n - 2);
}

int main() {
    int factorialNumber;
    int fibonacciTerms;

    // --- Part 1: Factorial Demonstration ---
    cout << "=== Factorial Demonstration ===" << endl;
    cout << "Enter a non-negative integer to find its factorial: ";
    cin >> factorialNumber;

    if (factorialNumber < 0) {
        cout << "Error: Factorial is not defined for negative numbers." << endl;
    } else {
        cout << "Factorial of " << factorialNumber << " is: " 
             << calculateFactorial(factorialNumber) << endl;
    }

    cout << "\n================================\n" << endl;

    // --- Part 2: Fibonacci Demonstration ---
    cout << "=== Fibonacci Series Demonstration ===" << endl;
    cout << "Enter the number of terms for the Fibonacci series: ";
    cin >> fibonacciTerms;

    if (fibonacciTerms <= 0) {
        cout << "Please enter a positive number of terms." << endl;
    } else {
        cout << "Fibonacci Series up to " << fibonacciTerms << " terms: " << endl;
        for (int i = 0; i < fibonacciTerms; i++) {
            cout << getFibonacci(i) << " ";
        }
        cout << endl;
    }

    return 0;
}

