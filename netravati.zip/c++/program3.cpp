//write a C++ program to demonastrate function overloading and default arguments
#include <iostream>
using namespace std;

// Function Overloading

int add(int a, int b) {
    return a + b;
}

double add(double a, double b) {
    return a + b;
}

int add(int a, int b, int c) {
    return a + b + c;
}

string add(string a, string b) {
    return a + b;
}
//default Argument
void displayInfo(string name, int age = 18, string city = "Unknown") {
    cout << "Name: " << name << ", Age: " << age << ", City: " << city << endl;
}

int main() {
    cout << "--- Function Overloading ---" << endl;
    cout << "add(2, 3) = " << add(2, 3) << endl;
    cout << "add(2.5, 3.7) = " << add(2.5, 3.7) << endl;
    cout << "add(1, 2, 3) = " << add(1, 2, 3) << endl;
    cout << "add(\"Hello \", \"World\") = " << add(string("Hello "), string("World")) << endl;
	   
    cout << "\n--- Default Arguments ---" << endl;
    displayInfo("Alex");                // Uses both defaults
    displayInfo("Bob", 25);             // Uses one default (city)
    displayInfo("Charlie", 30, "New York"); // No defaults used
    return 0;
}
