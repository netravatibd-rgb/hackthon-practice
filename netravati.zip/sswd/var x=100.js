var x=100
x='Mike'

const obj = { width: 10, height: 15};
const area = obj.width * obj.height;

let a= 