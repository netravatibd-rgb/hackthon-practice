let name = "Netravati";
let marks = 99
console.log(`My name is ${name} and I got ${marks} in this year`)