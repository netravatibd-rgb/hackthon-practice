function getnumbers(...numbers){
    console.log(numbers);
}
getnumbers(10,20,30,40)

//one more example

function sum(...numbers){
    return numbers.reduce((total,num)=>total+num,0);
}
console.log(`Total sum = ${sum(10,20,30,40)}`);

function student(name,...subjects){
    console.log("Nmae:",name);
    console.log("Subjects:",subjects);
}
student("Abc","C","C++","Python");