const person = {
    name: "Netra",greet: function(){
        console.log("Hello "+this.name);
    }
};
person.greet();

function greet(name = "Guest"){
    return "Hello " +name;
}
console.log(greet("Netra"));
console.log(greet());

function calculate(price= 100,quantity=2){
    return price*quantity;
}
console.log(calculate());
console.log(calculate(50, 3));

