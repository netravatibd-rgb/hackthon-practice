const promise = new 
Promise((resolve, reject)=>{
    const success = true;
    if (success){
        resolve("Event successful");
    }else{
        reject("Event failed");
    }
});
promise
    .then(result =>console.log(result))
    .catch(error =>console.error(error))
    .finally(() =>console.log("Finished"));
    
