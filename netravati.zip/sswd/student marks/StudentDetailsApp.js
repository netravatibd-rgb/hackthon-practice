import { student } from "./studentinfo.js";
document.getElementById("studentId").textContent = studentInfo.id;
document.getElementById("name").textContent = studentInfo.name;
document.getElementById("course").textContent = studentInfo.course;
document.getElementById("marks").textContent = studentInfo.marks;