import { studentName, displayStudent } from "./studentinfo.js";
displayStudent();