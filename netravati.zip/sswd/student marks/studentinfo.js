export const studentName = "Mike";

export function displayStudent(){
    console.log("Student Name:" + studentName);
}