var colors = require('colors/safe');

console.log(colors.red('Hello'));
console.log(colors.yellow('Hello'));
console.log(colors.grey('Hello'));
console.log(colors.bgBlue('Hello'));

console.log('hello'.green);
console.log('I like cake and pies'.undlined );
console.log('inverse the color'.invrse);
