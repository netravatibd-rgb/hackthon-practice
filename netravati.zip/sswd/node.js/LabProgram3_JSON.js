const employeeData =`
[
    {
        "id":101,
        "name":"Rahul",
        "department":"IT",
        "salary":45000
    },
    {
        "id":102,
        "name":"Priva",
        "department":"HR",
        "salary":40000
    },
    {
        "id":103,
        "name":"Amit",
        "department":"Finance",
        "salary":50000
    }
]
`;

function getEmployees(){
    return new Promise((resolve, reject)=>{
        try{
            const employees = JSON.parse(employeeData);
            resolve(employees);
        }catch (error){
            reject(error);
        }
    });
}
getEmployees()
    .then(employees => {
        console.log("Employee Data using promise:");

        employees.forEach(employee => {
            console.log(
                employee.id + "-" +
                employee.name + "-" +                
                employee.department + "- ₹" +
                employee.salary
            );
        });
    })
    .catch(error => {
        console.log
    })