var fs=reqire('s');
fs.writeFileSync("ArchExample.txt","Trying with Architecture Module")