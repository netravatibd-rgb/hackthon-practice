const fs=require("fs");
console.log("ASyn Start")
fs.readFile("ArchExample.txt","utf-8",(err,result)=>{
    console.log(result);
})
console.log("End")

console.log("Start")
const result=fs.readFileSync("ArchExample.txt","utf-8");
console.log(result);
console.log("End")