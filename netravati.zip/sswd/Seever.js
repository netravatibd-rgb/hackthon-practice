const http=require('http');
http.createServer((req,resp) => {
    resp.write("Server response It is a KLETECH")
    resp.end("hello")
}).listen(4800)