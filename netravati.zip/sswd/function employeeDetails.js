function employeeDetails(){
    let employeeName = "ABC";
    console.log(employeeName);
}
employeeDetails();
