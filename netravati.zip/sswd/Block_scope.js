if (true){
    let age = 25;
    const name = "xyz";
    console.log(age);
    console.log(name);
}
