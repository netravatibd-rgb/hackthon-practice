let company ="Goldman Sachs";
function displayCompany(){
    console.log(company);
}
displayCompany();
console.log(company);
