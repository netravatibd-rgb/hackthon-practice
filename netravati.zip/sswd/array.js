let numbers = [10, 20, 30];
let [a,b, c,] = numbers;
console.log(`Value at position a =${a}`);
console.log(b);
console.log(c);

let numbers = [10, 20, 30];
let [a, ,c] = numbers;
console.log(a);
console.log(c);
