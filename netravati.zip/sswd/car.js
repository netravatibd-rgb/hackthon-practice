let myCar = "auddi";
function BuyCar(){
    console.log(myCar)
}
BuyCar();
