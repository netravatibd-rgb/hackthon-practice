let name  ="Rahul";
let age = 20;
console.log("My name is "+name+" and I am "+ age + " yers old.");
