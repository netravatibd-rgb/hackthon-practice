const greet = () => "Hello, Good Morning";
console.log(greet());

const wish  = () => "Happy Brithday";
console.log(wish());

const square = x => x*x;
console.log(square(5));

const qube = y => y*y*y;
console.log(qube(5));

const multiply = (a, b) => a*b;
console.log(multiply(10, 20));

const division = (a, b) => a/b;
console.log(division(6,2));

const calculate = (a,b) => {
    let result = a+b;
    return result; 
};
console.log(calculate(10, 5));

