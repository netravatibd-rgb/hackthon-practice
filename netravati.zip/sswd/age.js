let age = 25;
age = 26;
console.log(age);

const country = "India";
country = "USA";
console.log(country)
