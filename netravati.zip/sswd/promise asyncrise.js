function getStudentData(){
    return new Promise((resolve, reject) =>{
        setTimeout(() => {
            const success = true;
            if (success){
                resolve({
                    id:101,
                    name:"Netra",
                    course:"BCA",
                    marks:85
                });
            }else{
                reject("Unable to get student data");
            }
        },5000);
    });
}
async function displayStudent(){
    console.log("Fetching student data...");
    try{
        const student = await getStudentData();
        console.log("Student ID:",student.id);
        console.log("Student Name:",student.name);
        console.log("Course:",student.course);
        console.log("Marks:",student.marks);
    }catch (error){
        console.log("Error:",error);
    }
}
displayStudent();
console.log("Program continues...");
console.log("Start")
setTimeout(()=>{
    console.log("Hello wait for 2seconda")
},2000);
console.log("End")