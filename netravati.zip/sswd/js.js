let name ="rahul";
let age=21;
let college = "ABC college";
let department = "MCA";
let semester =3;
let city ="Belagavi";

console.log("----Student Details---");
console.log("Name :",name);
console.log("Age :",age);
console.log("College :",college);
console.log("Department :",department);
console.log("Semester :",semester);
console.log("City :",city);