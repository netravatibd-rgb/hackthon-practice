const products = {

    clothes:{
        name:"Men's Cotton T-Shirt",
        price:"$19.99",
        image:"box1_image.jpg",
        description:"Premium cotton T-shirt for everyday wear."
    },

    health:{
        name:"Health Care Kit",
        price:"$25.00",
        image:"box2_image.jpg",
        description:"Complete personal healthcare essentials."
    },

    furniture:{
        name:"Wooden Chair",
        price:"$99.99",
        image:"box3_image.jpg",
        description:"Comfortable wooden chair for home."
    },

    electronics:{
        name:"Wireless Headphones",
        price:"$149.99",
        image:"box4_image.jpg",
        description:"Noise cancelling Bluetooth headphones."
    },

    beauty:{
        name:"Beauty Collection",
        price:"$49.99",
        image:"box5_image.jpg",
        description:"Premium beauty products."
    },

    pet:{
        name:"Pet Food",
        price:"$18.50",
        image:"box6_image.jpg",
        description:"Healthy pet food."
    },

    new:{
        name:"New Arrival Product",
        price:"$75.00",
        image:"box7_image.jpg",
        description:"Latest trending item."
    },

    fashion:{
        name:"Fashion Collection",
        price:"$89.99",
        image:"box8_image.jpg",
        description:"Modern fashion collection."
    }

};

const params = new URLSearchParams(window.location.search);

const product = params.get("product");

const data = products[product];

document.getElementById("productName").innerHTML = data.name;
document.getElementById("productPrice").innerHTML = data.price;
document.getElementById("productDescription").innerHTML = data.description;
document.getElementById("productImage").src = data.image;

function addCart(){

    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    const existing = cart.find(item => item.name === data.name);

    if(existing){

        existing.quantity++;

    }else{

        data.quantity = 1;

        cart.push(data);

    }

    localStorage.setItem("cart", JSON.stringify(cart));

    alert("Added to Cart!");

}