let cart = JSON.parse(localStorage.getItem("cart")) || [];

let container = document.getElementById("cartItems");

let total = 0;

// If quantity doesn't exist, set it to 1
cart.forEach(item => {
    if (!item.quantity) {
        item.quantity = 1;
    }
});

function displayCart() {

    container.innerHTML = "";

    total = 0;

    cart.forEach((item, index) => {

        let price = Number(item.price.replace("$",""));

        total += price * item.quantity;

        container.innerHTML += `
        <div class="cart-item">

            <img src="${item.image}" width="120">

            <div>

                <h2>${item.name}</h2>

                <h3>${item.price}</h3>

                <p>
                    <button onclick="decrease(${index})">-</button>

                    ${item.quantity}

                    <button onclick="increase(${index})">+</button>
                </p>

                <p><strong>Subtotal:</strong> $${(price * item.quantity).toFixed(2)}</p>

                <button onclick="removeItem(${index})">
                    Remove
                </button>

            </div>

        </div>
        `;
    });

    document.getElementById("totalPrice").innerHTML =
        "Total : $" + total.toFixed(2);

    localStorage.setItem("cart", JSON.stringify(cart));
}

displayCart();

function increase(index){

    cart[index].quantity++;

    displayCart();

}

function decrease(index){

    if(cart[index].quantity > 1){

        cart[index].quantity--;

    }

    displayCart();

}

function removeItem(index){

    cart.splice(index,1);

    displayCart();

}