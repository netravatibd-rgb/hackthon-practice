// Welcome message
console.log("Amazon Clone Loaded Successfully!");

// Back To Top button
const backToTop = document.querySelector(".foot-panel1");

backToTop.addEventListener("click", () => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});

// Search button click
const searchIcon = document.querySelector(".search-icon");
const searchInput = document.querySelector(".search-input");

searchIcon.addEventListener("click", () => {
    if(searchInput.value.trim() !== ""){
        alert("Searching for: " + searchInput.value);
    } else {
        alert("Please enter something to search.");
    }
});

// Enter key support
searchInput.addEventListener("keypress", (e) => {
    if(e.key === "Enter"){
        searchIcon.click();
    }
});

const heroSection = document.querySelector(".hero-section");

const images = [
    "hero_image.jpg",
    "box1_image.jpg",
    "box2_image.jpg",
    "box3_image.jpg"
];

let current = 0;

setInterval(() => {
    current++;

    if(current >= images.length){
        current = 0;
    }

    heroSection.style.backgroundImage =
        `url('${images[current]}')`;

}, 3000);

// Update cart count
function updateCartCount(){

    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    document.getElementById("cartBadge").textContent = cart.length;

}

updateCartCount();

// Run when page loads
