num1 = int(input("Enter a number"))
num2 = int(input("Enter a number"))

print("Addition of numbers",num1 + num2)
print("sustraction of numbers",num1 - num2)
print("Multiplication of numbers",num1 * num2)
print("Division of numbers",num1 / num2)

